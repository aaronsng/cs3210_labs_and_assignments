#ifndef GOI_OMP_H
#define GOI_OMP_H

int goi(int nThreads, int nGenerations, const int *startWorld, int nRows, int nCols, int nInvasions, const int *invasionTimes, int **invasionPlans);

#endif
