#ifndef GOI_THREADS_H
#define GOI_THREADS_H

int goi(int nThreads, int nGenerations, const int *startWorld, int nRows, int nCols, int nInvasions, const int *invasionTimes, int **invasionPlans);

#endif
